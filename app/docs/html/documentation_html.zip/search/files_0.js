var searchData=
[
  ['color_2ekt_0',['Color.kt',['../_color_8kt.html',1,'']]]
];
