var searchData=
[
  ['repositorymodule_2ekt_0',['RepositoryModule.kt',['../_repository_module_8kt.html',1,'']]],
  ['roomdatabase_1',['RoomDatabase',['../namespace_room_database.html',1,'']]]
];
