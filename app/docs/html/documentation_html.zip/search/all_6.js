var searchData=
[
  ['handle_0',['handle',['../namespace_insert_exercise_use_case.html#adbdbbd23da77d2e6eedc45b751354900',1,'InsertExerciseUseCase.handle()'],['../namespace_update_exercise_use_case.html#aec9e60e6dfa85e13f27b049fa5a41c74',1,'UpdateExerciseUseCase.handle()']]]
];
