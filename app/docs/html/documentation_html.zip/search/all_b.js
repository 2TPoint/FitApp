var searchData=
[
  ['oncreate_0',['onCreate',['../namespace_application.html#a6cb5121e058c421df07e51238e0c86c7',1,'Application.onCreate()'],['../namespace_component_activity.html#ac93e02521caa7c6608824507a471b057',1,'ComponentActivity.onCreate()']]]
];
