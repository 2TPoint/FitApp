var searchData=
[
  ['viewmodelmodule_2ekt_0',['ViewModelModule.kt',['../_view_model_module_8kt.html',1,'']]]
];
