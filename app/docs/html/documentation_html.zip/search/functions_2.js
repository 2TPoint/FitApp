var searchData=
[
  ['getexercises_0',['getExercises',['../namespace_exercise_repository.html#a357969b4b3d7be643a3f824306b49433',1,'ExerciseRepository']]]
];
