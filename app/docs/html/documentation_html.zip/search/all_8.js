var searchData=
[
  ['koinviewmodel_0',['koinViewModel',['../namespacekoin_view_model.html',1,'']]]
];
