var searchData=
[
  ['settingsscreen_0',['SettingsScreen',['../_settings_screen_controller_8kt.html#ae3de22319b80832a3096bb719fe6c8ae',1,'SettingsScreenController.kt']]]
];
