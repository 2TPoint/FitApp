var searchData=
[
  ['toggleoption_0',['ToggleOption',['../_settings_screen_controller_8kt.html#a33afe604d3d0f08c762ba03b946d3971',1,'SettingsScreenController.kt']]]
];
