var searchData=
[
  ['repositorymodule_2ekt_0',['RepositoryModule.kt',['../_repository_module_8kt.html',1,'']]]
];
