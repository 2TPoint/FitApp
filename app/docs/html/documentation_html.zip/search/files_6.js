var searchData=
[
  ['mainactivity_2ekt_0',['MainActivity.kt',['../_main_activity_8kt.html',1,'']]]
];
