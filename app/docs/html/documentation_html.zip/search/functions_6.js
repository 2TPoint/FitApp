var searchData=
[
  ['popupscreen_0',['PopupScreen',['../_popup_screen_controller_8kt.html#ab18aa7ae870a53526f1ce7f033ec21c6',1,'PopupScreenController.kt']]]
];
